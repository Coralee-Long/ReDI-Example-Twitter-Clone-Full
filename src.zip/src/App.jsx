import { useState, useEffect, createContext } from 'react';
import TweetInput from './components/TweetInput';
import TweetList from './components/TweetList';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Profile from './components/Profile';
import fallbackData from './data/fallback_data.json'; // Import the fallback JSON file

import './App.css';

export const AppContext = createContext();

const App = () => {
	const [tweets, setTweets] = useState([]);
	const [user, setUser] = useState({
		name: 'Joe Smith',
		profilePicture: '/avatar.jpg',
	});
	const [theme, setTheme] = useState('light');

	useEffect(() => {
		fetchTweets();
	}, []);

	const fetchTweets = async () => {
		console.log('fetching tweets');

		try {
			const response = await fetch(
				'https://my.api.mockaroo.com/tweets?key=c8f44730'
			);

			if (!response.ok) {
				console.error('API request failed with status:', response.status);
				setTweets(fallbackData); // Use fallback data if the response is not OK
				return;
			}

			const data = await response.json();

			if (data && Array.isArray(data)) {
				setTweets(data); // Use the API response if valid
			} else {
				console.warn(
					'Invalid or empty response from API, using fallback data.'
				);
				setTweets(fallbackData); // Use fallback data if API response is invalid
			}
		} catch (error) {
			console.error('Error fetching tweets:', error);
			setTweets(fallbackData); // Use fallback data if an error occurs
		}
	};

	const addTweet = (tweet) => {
		setTweets([tweet, ...tweets]);
	};

	return (
		<AppContext.Provider value={{ user, setUser, theme, setTheme }}>
			<div className={`app ${theme === 'dark' ? 'dark-mode' : ''}`}>
				<Header className='app-header' />
				<div className='app-main'>
					<Sidebar className='app-sidebar' />
					<main className='app-content'>
						<Profile
							className='app-profile'
							user={user}
						/>
						<TweetInput
							addTweet={addTweet}
							tweets={tweets}
							className='app-tweet-input'
						/>
						<TweetList
							tweets={tweets}
							className='app-tweet-list'
						/>
					</main>
				</div>
			</div>
		</AppContext.Provider>
	);
};

export default App;
