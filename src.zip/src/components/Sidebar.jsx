import '../styles/Sidebar.css';

const Sidebar = () => {
	return (
		<aside className='sidebar'>
			<button className='sidebar-button'>Home</button>
			<button className='sidebar-button'>Explore</button>
			<button className='sidebar-button'>Notifications</button>
			<button className='sidebar-button'>Messages</button>
		</aside>
	);
};

export default Sidebar;
