import '../styles/Header.css';

const Header = ({ theme, toggleTheme }) => {
	return (
		<header className='header'>
			<h1 className='header-title'>Twitter Clone</h1>
			<button
				className='header-toggle'
				onClick={toggleTheme}>
				{theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
			</button>
		</header>
	);
};

export default Header;
