import '../styles/Tweet.css';

const Tweet = ({ tweet }) => {
	return (
		<li className='tweet-list-item'>
			<img
				src={tweet.thumbnail || '/gen-avatar.png'}
				alt={`${tweet.name}'s avatar`}
				className='tweet-avatar'
			/>
			<div className='tweet-content-container'>
				<div className='tweet-header'>
					<span className='tweet-author'>{tweet.name}</span>
					<span className='tweet-date'>
						{new Date(tweet.publishedAt).toLocaleString()}
					</span>
				</div>
				<p className='tweet-content'>{tweet.content}</p>
				<div className='tweet-buttons-container'>
					<button className='tweet-button'>Like</button>
					<button className='tweet-button'>Retweet</button>
					<button className='tweet-button'>Reply</button>
				</div>
			</div>
		</li>
	);
};

export default Tweet;
